import mysql.connector

def get_database_connection():
    connection = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="billarG8"
    )
    return connection

# Define aquí las funciones para otras operaciones relacionadas con la base de datos, si es necesario