from flask import Blueprint, render_template, request
from database import get_database_connection

config_bp = Blueprint('config', __name__)

def insert_config_into_database(GameMode, Players, GameTime):
    try:
        # Obtener la conexión a la base de datos
        connection = get_database_connection()

        # Crear un cursor para ejecutar consultas
        cursor = connection.cursor()

        # Ejecutar la sentencia INSERT para insertar la configuración de partida en la tabla "partida"
        insert_query = """
            INSERT INTO partida (GameMode, Players, GameTime)
            VALUES (%s, %s, %s)
        """
        config_data = (GameMode, Players, GameTime)
        cursor.execute(insert_query, config_data)

        # Confirmar los cambios en la base de datos
        connection.commit()

        # Cerrar el cursor y la conexión
        cursor.close()
        connection.close()

        return True  # Si la configuración se guarda correctamente, devuelve True
    except Exception as e:
        # Si ocurre un error, imprime el mensaje de error y devuelve False
        print("Error al guardar la configuración de partida:", e)
        return False

@config_bp.route('/config', methods=['GET', 'POST'])
def config_handler():
    if request.method == 'POST':
        # Procesar el formulario y guardar la configuración de la partida
        GameMode = request.form["GameMode"]
        Players = request.form["Players"]
        GameTime = request.form["GameTime"]

        # Guardar la configuración de la partida en la base de datos
        if insert_config_into_database(GameMode, Players, GameTime):
            return "Configuración de partida guardada correctamente"
        else:
            return "Error al guardar la configuración de partida. Por favor, inténtalo nuevamente."

    # Renderizar el formulario de configuración de partida
    return render_template('config_partida.html')