from flask import Blueprint, render_template, session

perfil_bp = Blueprint('perfil', __name__)

@perfil_bp.route('/perfil')
def show_perfil():
    user_id = session.get('user_id')
    username = session.get('username')
    # Obtener información del usuario desde la sesión o la base de datos si es necesario
    # ... (código para obtener información del usuario)

    return render_template('perfil.html', user_id=user_id, username=username)