from flask import Blueprint, render_template, request

user_bp = Blueprint('user', __name__)

def login_handler(nodocumento, password):
    # Aquí implementa la lógica para verificar las credenciales del usuario en la base de datos
    # y devuelve el usuario si las credenciales son válidas o None si no lo son.
    # Por ejemplo:
    # user = get_user_by_nodocumento(nodocumento)
    # if user and user['password_user'] == password:
    #     return user
    # return None
    pass

def registrar(userName, lastName, email, nodocumento, password_user):
    # Aquí implementa la lógica para registrar un nuevo usuario en la base de datos
    # y devuelve True si el registro fue exitoso o False si no lo fue.
    # Por ejemplo:
    # if not user_exists(nodocumento):
    #     create_new_user(userName, lastName, email, nodocumento, password_user)
    #     return True
    # return False
    pass