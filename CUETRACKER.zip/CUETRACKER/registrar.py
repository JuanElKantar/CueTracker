from flask import Blueprint, render_template, request
from database import get_database_connection

registrar_bp = Blueprint('registrar', __name__)

def insert_user_into_database(userName, lastName, email, nodocumento, password_user):
    try:
        # Obtener la conexión a la base de datos
        connection = get_database_connection()

        # Crear un cursor para ejecutar consultas
        cursor = connection.cursor()

        # Ejecutar la sentencia INSERT para insertar el nuevo usuario en la tabla "users"
        insert_query = """
            INSERT INTO users (userName, lastName, email, nodocumento, password_user)
            VALUES (%s, %s, %s, %s, %s)
        """
        user_data = (userName, lastName, email, nodocumento, password_user)
        cursor.execute(insert_query, user_data)

        # Confirmar los cambios en la base de datos
        connection.commit()

        # Cerrar el cursor y la conexión
        cursor.close()
        connection.close()

        return True  # Si el registro se realiza correctamente, devuelve True
    except Exception as e:
        # Si ocurre un error, imprime el mensaje de error y devuelve False
        print("Error al registrar usuario:", e)
        return False

@registrar_bp.route("/registrar", methods=["GET", "POST"])
def registrar_handler():
    if request.method == 'POST':
        # Procesar el formulario y registrar un nuevo usuario
        userName = request.form["userName"]
        lastName = request.form["lastName"]
        email = request.form["email"]
        nodocumento = request.form["nodocumento"]
        password_user = request.form["password_user"]

        # Insertar el nuevo usuario en la base de datos
        if insert_user_into_database(userName, lastName, email, nodocumento, password_user):
            return "Usuario registrado correctamente"
        else:
            return "Error al registrar usuario. Por favor, inténtalo nuevamente."

    # Renderizar el formulario de registro
    return render_template('registrar_usuario.html')